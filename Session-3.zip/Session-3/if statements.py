database = ['Liam', 'Joshua', 'Brittany']

username = input("What is your name ? : ")

if username in database:
    print("login successful!")
else:
    print("login unsuccessful!")



if 3 > 2:
    print('3 is bigger than 2')
elif 3 < 2: 
    print('2 is bigger than 3')
if 1 == 1: 
    Print('1 is equal to 1')
elif 1 != 1: 
    Print('1 is not equal to 1')

player_list = ['Liam', 'Joshua', 'Brittany']


for player in player_list:
    print(player)

count = 0
for player in player_list:
    print(player, count)
    count += 1

for integer in range(5):
    print(integer)

    
Time = 0
while (Time < 12): 
    Print('good morning')
    Time += 1

TeamSupported = input('Which team do you support ? : ')
while (TeamSupported == 'Man Utd'):
    print('deaddddddd')
    TeamSupported = input('Which team do you support ? : ')
else:
    print("Nice")
